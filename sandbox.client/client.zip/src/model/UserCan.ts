export enum UserCan {
  VIEW_USERS = "VIEW_USERS",
  VIEW_ABOUT = "VIEW_ABOUT",
}
