export class Client {
  public id: number;
  public surname: string;
  public name: string;
  public tname: string;
  public charm: string;
  public min_money: any;
  public max_money: any;
  public birth_date: any;
  public address: string;
}
