import {Component, HostBinding, OnInit} from '@angular/core';
import {ClientService} from "../service/client.service";
import {Client} from "../../model/client";
import {Router} from "@angular/router";
import {MatDialog} from "@angular/material";
import {EditClientComponent} from "../edit-client/edit-client.component";
import {AddClientComponent} from "../add-client/add-client.component";

@Component({
  selector: 'app-client-list',
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.css']
})
export class ClientListComponent implements OnInit {

  currDate = new Date();
  clients: Client[] = [];
  clicked = false;
  orders = [{'name': 'name'}, {'name': 'surname'}, {'name': 'tname'}];
  selectedOrder = this.orders[0].name;

  @HostBinding('class.is-open')
  isOpen = false;

  constructor(public clientService: ClientService,
              public dialog: MatDialog) {
  }

  ngOnInit() {
    this.loadClients()
  }

  loadClients() {
    this.clientService.getClients().subscribe(data => {
      this.clients = data;
    });
  }

  onClickMe(str: string) {
    if (this.clicked == false) {
      this.loadSorted(str, 'desc')
      this.clicked = true;
    } else {
      this.loadSorted(str, 'asc');
      this.clicked = false;
    }
  }

  loadSorted(orderBy: string, asc: string): void {
    this.clientService.orderClients(orderBy, asc).subscribe(data => {
      this.clients = data;
    });
  }

  deleteClient(client: Client): void {
    this.clientService.deleteClient(client.id).subscribe(data => {
      this.clients = this.clients.filter(u => u !== client);
    })
  }


  onKey(str: string) {
    this.clientService.filterClientsBy(this.selectedOrder, str).subscribe(
      data => {
        this.clients = data;
      }
    );
    if (!str) {
      this.loadClients();
    }
  }

  editClient(id: number,): void {
    localStorage.removeItem("editClientId");
    localStorage.setItem("editClientId", id.toString());
    const dialogRef = this.dialog.open( EditClientComponent, {
    });

    dialogRef.afterClosed().subscribe(result => {
      this.loadClients();
    });
  }
  addClient(){
    const dialogRef = this.dialog.open( AddClientComponent, {
    });

    dialogRef.afterClosed().subscribe(result => {
      this.loadClients();
    });
  }


}
