import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Client} from "../../model/client";

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  constructor(private http: HttpClient) { }
  baseUrl: string = 'http://localhost:3000/users';

  getClients(){
    return this.http.get<Client[]>(this.baseUrl);
  }

  orderClients(str: String, asc: String){
    return this.http.get<Client[]>(this.baseUrl+'?_sort='+str+'&_order='+asc);
  }

  getClientById(id: number){
    return this.http.get<Client>(this.baseUrl+'/'+id);
  }

  filterClientsBy(str1: string, str2: string){
    return this.http.get<Client[]>(this.baseUrl+'?'+str1+"_like="+str2);
  }

  createClient(client: Client){
    return this.http.post(this.baseUrl, client);
  }

  updateClient(client: Client){
    return this.http.put(this.baseUrl+'/'+client.id, client)
  }

  deleteClient(id: number){
    return this.http.delete(this.baseUrl+'/'+id);
  }
}
