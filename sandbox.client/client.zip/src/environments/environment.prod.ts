export const environment = {
  production: true,
  urlPrefix: '/api',
};
